using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations;
using System;
 
namespace LoginAndRegistration.Models
{
    public class Registration
    {
        [Key]
        public long Userid {get;set;}
        [Required]
        [MinLength(2)]
        [MaxLength(45)]
        public string FirstName {get; set;}
        [Required]
        [MinLength(2)]
        [MaxLength(45)]
        public string LastName {get; set;}
        [Required]
        [MinLength(2)]
        [MaxLength(45)]
        public string Email {get; set;}        
        [Required]
        [MinLength(5)]
        [MaxLength(255)]
        public string Password {get; set;}

    }
}