using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System;
 
namespace Products.Models
{
    public class Categories
    {
        public long Categoryid {get; set;}

        [Required]
        public string Name {get; set;}
                
        public DateTime Created_At {get; set;}

        public DateTime Updated_At {get; set;}

        public List<ProdCat> Products {get; set;}

        public Categories()
        {
            Created_At = DateTime.Now;
            Updated_At = DateTime.Now;
            Products = new List<ProdCat>();
        }
    }
}