using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System;
 
namespace Products.Models
{
    public class ProdCat
    {
        [Key]
        public long ProdCatid {get; set;}

        public long Categoryid {get; set;}
        public Categories Category {get; set;}

        public long Productid {get; set;}
        public Product Product {get; set;}

    }
}

        