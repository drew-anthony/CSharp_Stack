using Microsoft.EntityFrameworkCore;
 
namespace Products.Models
{
    public class ProdContext : DbContext
    {
        // base() calls the parent class' constructor passing the "options" parameter along
        public ProdContext(DbContextOptions<ProdContext> options) : base(options) { }
        public DbSet<Product> Products { get; set; }
        public DbSet<Categories> Categories { get; set; }
        public DbSet<ProdCat> ProdCat { get; set; }
    }
}