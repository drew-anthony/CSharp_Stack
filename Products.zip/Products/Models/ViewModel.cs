using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System;
 
namespace Products.Models
{
    public class ViewModel
    {
        public Product Product {get; set;}
        public Categories Category {get; set;}
        public ProdCat ProductCategory {get; set;}
        public List<Product> usedProducts  = new List<Product>();
        public List<Product> unusedProducts  = new List<Product>();
        public List<Categories> usedCategories = new List<Categories>();
        public List<Categories> unusedCategories = new List<Categories>();

        public List<Categories> allCategories = new List<Categories>();
        public List<Product> allProducts = new List<Product>();
        
        public List<ProdCat> allProductsCategories {get; set;}
    }
}