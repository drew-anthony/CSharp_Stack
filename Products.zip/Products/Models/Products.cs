using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System;
 
namespace Products.Models
{
    public class Product
    {
        public long Productid {get; set;}
        [Required]
        public long name {get; set;}
        [Required]
        public string description{get; set;}
        [Required]
        public decimal price {get; set;}

        public DateTime Created_At {get; set;}

        public DateTime Updated_At {get; set;}

        public List<ProdCat> Categories {get; set;}
        public Product()
        {
            Created_At = DateTime.Now;
            Updated_At = DateTime.Now;
            Categories = new List<ProdCat>();
        }
    }
}