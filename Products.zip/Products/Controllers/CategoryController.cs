using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Products.Models;
using System.Data;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Extensions;


namespace Products.Controllers
{
    public class CategoryController : Controller
    {
        private ProdContext _context;

        public CategoryController(ProdContext context)
        {
            _context = context;
        }

        //new category main page
        [HttpGet("products/new")]
        public IActionResult New()
        {
            return View();
        }
        
        
        //creating a new category
        [HttpPost("categories/create")]
        public IActionResult Create(Categories category)
        {
            if(ModelState.IsValid)
            {
                _context.Categories.Add(category);
                _context.SaveChanges();

                return RedirectToAction("OneCat", new{id = category.Categoryid});
            }
            else
            {
                return View("NewCategory");
            }
        }
    }
}