using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Products.Models;

namespace Products.Controllers
{
    public class ProductController : Controller
    {
        private ProdContext _context;

        public ProductController(ProdContext context)
        {
            _context = context;
        }

        //creating a new product
        [HttpPost("products/create")]
        public IActionResult Create(Product product)
        {
            if(ModelState.IsValid)
            {
                _context.Products.Add(product);
                _context.SaveChanges();

                return RedirectToAction("OneCat", new{id = product.Productid});
            }
            else
            {
                return View("NewCategory");
            }
        }

        
    }
}